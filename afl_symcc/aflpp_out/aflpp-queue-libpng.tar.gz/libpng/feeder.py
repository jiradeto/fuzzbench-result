import time
import subprocess, threading
import os
import random

AFL_QUEUE_PATH='/out/QUEUE'
SYMCC_TARGET_BINARY='/out/uninstrumented/libpng_read_fuzzer'

OUT_DIR=os.path.dirname(os.path.realpath(__file__)) + "/PRE_FUZZING_OUT"
MAX_INPUT=50
FUZZING_MAX_SECONS=500

all_inputs = os.listdir(AFL_QUEUE_PATH)
selected_items = random.choices(all_inputs, k=MAX_INPUT)
selected_items = list(map(lambda x: AFL_QUEUE_PATH+"/"+x, selected_items))

# print(selected_items)

# os.environ['SYMCC_INPUT_FILE'] = 'clang'
# os.environ['SYMCC_OUTPUT_DIR'] = 'clang'

print('Feeding AFL generated inputs into symcc ...')

class RunCmd(threading.Thread):
  def __init__(self, cmd, timeout):
    threading.Thread.__init__(self)
    self.cmd = cmd
    self.timeout = timeout

  def run(self):
    self.p = subprocess.Popen(self.cmd)
    self.p.wait()

    self.join(self.timeout)
  def Run(self):
    self.start()
    self.join(self.timeout)

    if self.is_alive():
      self.p.terminate()      #use self.p.kill() if process needs a kill -9
      self.join()

def bootstrap():    
    subprocess.run(["rm", "-rf", OUT_DIR])
    subprocess.run(["mkdir", OUT_DIR])


def run():
    for idx, item in enumerate(selected_items):
        generated_out_afl = OUT_DIR+"/"+str(idx)+"/"+"afl_generated"
        generated_out_sym = OUT_DIR+"/"+str(idx)+"/"+"sym_generated"
        subprocess.run(["mkdir", OUT_DIR+"/"+str(idx)])
        subprocess.run(["mkdir", generated_out_sym])
        subprocess.run(["mkdir", generated_out_afl])
        subprocess.run(["cp", item , (generated_out_afl+"/")])

        # print(item)
        os.environ['SYMCC_INPUT_FILE'] = item
        os.environ['SYMCC_OUTPUT_DIR'] = generated_out_sym
        
        cmd = SYMCC_TARGET_BINARY + " " + item
        RunCmd(cmd.split(" "), FUZZING_MAX_SECONS).Run() 

bootstrap()
run()


